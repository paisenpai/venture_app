"use client"

import { useState, useEffect } from "react"
import { useNavigate } from "react-router-dom"
import PageHeader from "../components/ui/PageHeader"
import { useTheme } from "../contexts/ThemeContext"
import { useAuth } from "../contexts/AuthContext"
import AchievementCard from "../components/character/AchievementCard"
import { userService } from "../services/userService"
import { characterData } from "../utils/achievements/characterData"

const Character = () => {
  const navigate = useNavigate()
  const { theme } = useTheme()
  const { user } = useAuth()
  const [userProfile, setUserProfile] = useState(null)
  const [userStats, setUserStats] = useState(null)
  const [achievements, setAchievements] = useState([])
  const [allAchievements, setAllAchievements] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  const isDemoUser = user?.id === "demo-user-123"

  useEffect(() => {
    loadCharacterData()
  }, [user])

  const loadCharacterData = async () => {
    try {
      setLoading(true)
      setError(null)

      if (isDemoUser) {
        // Use demo data for demo user
        setUserProfile({
          username: characterData.username,
          full_name: "Demo User",
          avatar_url: null,
        })
        setUserStats({
          total_xp: characterData.totalXP,
          level: characterData.level,
          current_streak: 7,
          tasks_completed: 45,
        })
        setAchievements(characterData.achievements)
        setAllAchievements(characterData.achievements)
      } else {
        // Load real data from database
        const [profile, stats, userAchievements, allAchievementsData] = await Promise.all([
          userService.getProfile(),
          userService.getUserStats(),
          userService.getUserAchievements(),
          userService.getAllAchievements(),
        ])

        setUserProfile(profile)
        setUserStats(stats)

        // Transform achievements data to match the expected format
        const transformedAchievements = allAchievementsData.map((achievement) => {
          const userAchievement = userAchievements.find((ua) => ua.achievement_id === achievement.id)
          return {
            id: achievement.id,
            name: achievement.name,
            stars: 3, // Default stars, you can adjust this based on achievement difficulty
            unlocked: !!userAchievement,
            icon: achievement.icon || "🏆",
            description: achievement.description,
          }
        })

        setAchievements(transformedAchievements)
        setAllAchievements(transformedAchievements)
      }
    } catch (err) {
      console.error("Error loading character data:", err)
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="w-full pl-[5%] pr-0">
        <PageHeader
          title="Character"
          variant="standard"
          size="large"
          className="mb-2 pb-1 border-b border-gray-200 dark:border-gray-700"
        />
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-500"></div>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="w-full pl-[5%] pr-0">
        <PageHeader
          title="Character"
          variant="standard"
          size="large"
          className="mb-2 pb-1 border-b border-gray-200 dark:border-gray-700"
        />
        <div className="flex justify-center items-center h-64">
          <div className="text-red-500">Error loading character data: {error}</div>
        </div>
      </div>
    )
  }

  return (
    <div className="w-full pl-[5%] pr-0">
      <PageHeader
        title="Character"
        variant="standard"
        size="large"
        className="mb-2 pb-1 border-b border-gray-200 dark:border-gray-700"
      />

      {/* Character Profile Section */}
      <div className="mb-10">
        <div className="flex items-center gap-8">
          {/* Avatar */}
          <div className="w-36 h-36 rounded-full overflow-hidden border-3 border-pink-300">
            {userProfile?.avatar_url ? (
              <img
                src={userProfile.avatar_url || "/placeholder.svg"}
                alt="User Avatar"
                className="w-full h-full object-cover"
              />
            ) : (
              <img src="https://placehold.co/144x144" alt="User Avatar" className="w-full h-full object-cover" />
            )}
          </div>

          {/* User info */}
          <div className="flex-1 h-36 flex flex-col pl-6">
            <div className="h-36 w-full flex flex-col justify-between py-4">
              {/* Username */}
              <h2 className="text-2xl font-bold text-indigo-800 dark:text-indigo-300">
                {userProfile?.username || userProfile?.full_name || "Adventurer"}
              </h2>

              {/* Stats */}
              <div className="flex flex-col gap-y-2 pr-[8%]">
                <div className="flex items-center">
                  <span className="text-grey-700 dark:text-grey-400 text-lg w-32 pr-4">TOTAL XP</span>
                  <span className="text-indigo-900 dark:text-indigo-300 text-lg font-bold">
                    {userStats?.total_xp || 0}
                  </span>
                </div>
                <div className="flex items-center">
                  <span className="text-grey-700 dark:text-grey-400 text-lg w-32 pr-4">Level</span>
                  <span className="text-indigo-900 dark:text-indigo-300 text-lg font-bold">
                    {userStats?.level || 1}
                  </span>
                </div>
                <div className="flex items-center">
                  <span className="text-grey-700 dark:text-grey-400 text-lg w-32 pr-4">Streak</span>
                  <span className="text-indigo-900 dark:text-indigo-300 text-lg font-bold">
                    {userStats?.current_streak || 0} days
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Achievements Section */}
      <div className="mb-8">
        <div className="flex items-center mb-4">
          <h3 className="text-lg font-bold text-indigo-900 dark:text-indigo-300 mr-4">
            Achievements ({achievements.filter((a) => a.unlocked).length}/{achievements.length})
          </h3>
          <div className="flex-1 h-px bg-gray-200 dark:bg-gray-700"></div>
        </div>

        {achievements.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-32 text-gray-500">
            <p className="text-center">No achievements available yet.</p>
            <p className="text-sm text-center mt-2">Complete quests to unlock achievements!</p>
          </div>
        ) : (
          <div className="grid grid-rows-2 auto-cols-max gap-3 overflow-x-auto pb-4">
            <div className="flex gap-3">
              {achievements.slice(0, Math.ceil(achievements.length / 2)).map((achievement) => (
                <AchievementCard key={achievement.id} achievement={achievement} />
              ))}
            </div>
            <div className="flex gap-3">
              {achievements.slice(Math.ceil(achievements.length / 2)).map((achievement) => (
                <AchievementCard key={achievement.id} achievement={achievement} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

export default Character
