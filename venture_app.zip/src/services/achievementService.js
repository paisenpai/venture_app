import { supabase } from "../lib/supabase"

export const achievementService = {
  // Populate achievement definitions (run this once to set up achievements)
  async populateAchievements() {
    const achievements = [
      // Streak-Based Achievements
      {
        name: "Rookie Adventurer",
        description: "Complete tasks 3 days in a row",
        category: "streak",
        required_days: 3,
        xp_reward: 50,
        icon_url: "/icons/rookie-adventurer.svg",
      },
      {
        name: "Dedicated Student",
        description: "Complete tasks 7 days in a row",
        category: "streak",
        required_days: 7,
        xp_reward: 100,
        icon_url: "/icons/dedicated-student.svg",
      },
      {
        name: "Persistent Scholar",
        description: "Complete tasks 21 days in a row",
        category: "streak",
        required_days: 21,
        xp_reward: 250,
        icon_url: "/icons/persistent-scholar.svg",
      },
      {
        name: "Habit Master",
        description: "Complete tasks 50 days in a row",
        category: "streak",
        required_days: 50,
        xp_reward: 500,
        icon_url: "/icons/habit-master.svg",
      },
      {
        name: "Legendary Consistency",
        description: "Complete tasks 100 days in a row",
        category: "streak",
        required_days: 100,
        xp_reward: 1000,
        icon_url: "/icons/legendary-consistency.svg",
      },

      // Level-Based Achievements
      {
        name: "First Steps",
        description: "Reach Level 2",
        category: "level",
        required_count: 2,
        xp_reward: 25,
        icon_url: "/icons/first-steps.svg",
      },
      {
        name: "Rising Star",
        description: "Reach Level 5",
        category: "level",
        required_count: 5,
        xp_reward: 75,
        icon_url: "/icons/rising-star.svg",
      },
      {
        name: "Skilled Adventurer",
        description: "Reach Level 10",
        category: "level",
        required_count: 10,
        xp_reward: 150,
        icon_url: "/icons/skilled-adventurer.svg",
      },
      {
        name: "Seasoned Hero",
        description: "Reach Level 20",
        category: "level",
        required_count: 20,
        xp_reward: 300,
        icon_url: "/icons/seasoned-hero.svg",
      },
      {
        name: "Elite Scholar",
        description: "Reach Level 35",
        category: "level",
        required_count: 35,
        xp_reward: 500,
        icon_url: "/icons/elite-scholar.svg",
      },
      {
        name: "Master Adventurer",
        description: "Reach Level 50",
        category: "level",
        required_count: 50,
        xp_reward: 750,
        icon_url: "/icons/master-adventurer.svg",
      },
      {
        name: "Legendary Student",
        description: "Reach Level 75",
        category: "level",
        required_count: 75,
        xp_reward: 1000,
        icon_url: "/icons/legendary-student.svg",
      },
      {
        name: "Ultimate Productivity Hero",
        description: "Reach Level 100",
        category: "level",
        required_count: 100,
        xp_reward: 1500,
        icon_url: "/icons/ultimate-hero.svg",
      },

      // XP-Based Achievements
      {
        name: "XP Collector",
        description: "Earn 500 total XP",
        category: "xp",
        required_count: 500,
        xp_reward: 50,
        icon_url: "/icons/xp-collector.svg",
      },
      {
        name: "XP Hunter",
        description: "Earn 2,500 total XP",
        category: "xp",
        required_count: 2500,
        xp_reward: 100,
        icon_url: "/icons/xp-hunter.svg",
      },
      {
        name: "XP Master",
        description: "Earn 10,000 total XP",
        category: "xp",
        required_count: 10000,
        xp_reward: 250,
        icon_url: "/icons/xp-master.svg",
      },
      {
        name: "XP Legend",
        description: "Earn 50,000 total XP",
        category: "xp",
        required_count: 50000,
        xp_reward: 500,
        icon_url: "/icons/xp-legend.svg",
      },

      // Task Completion Achievements
      {
        name: "Task Starter",
        description: "Complete your first task",
        category: "tasks",
        required_count: 1,
        xp_reward: 25,
        icon_url: "/icons/task-starter.svg",
      },
      {
        name: "Getting Things Done",
        description: "Complete 10 tasks",
        category: "tasks",
        required_count: 10,
        xp_reward: 75,
        icon_url: "/icons/getting-things-done.svg",
      },
      {
        name: "Productivity Pro",
        description: "Complete 50 tasks",
        category: "tasks",
        required_count: 50,
        xp_reward: 200,
        icon_url: "/icons/productivity-pro.svg",
      },
      {
        name: "Task Master",
        description: "Complete 100 tasks",
        category: "tasks",
        required_count: 100,
        xp_reward: 400,
        icon_url: "/icons/task-master.svg",
      },
    ]

    try {
      const { data, error } = await supabase.from("achievement_definitions").insert(achievements).select()

      if (error) throw error
      return data
    } catch (error) {
      console.error("Error populating achievements:", error)
      throw error
    }
  },
}
