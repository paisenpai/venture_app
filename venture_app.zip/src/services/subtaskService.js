import { supabase } from "../lib/supabase"

export const subtaskService = {
  // Get all subtasks for a specific quest
  async getSubtasks(parentTaskId) {
    try {
      const { data, error } = await supabase
        .from("subtasks")
        .select("*")
        .eq("parent_task_id", parentTaskId)
        .order("created_at", { ascending: true })

      if (error) throw error

      return data || []
    } catch (error) {
      console.error("Error fetching subtasks:", error)
      throw error
    }
  },

  // Create a new subtask
  async createSubtask(subtaskData) {
    try {
      const { data, error } = await supabase.from("subtasks").insert([subtaskData]).select().single()

      if (error) throw error

      return data
    } catch (error) {
      console.error("Error creating subtask:", error)
      throw error
    }
  },

  // Update a subtask
  async updateSubtask(subtaskId, subtaskData) {
    try {
      const { data, error } = await supabase.from("subtasks").update(subtaskData).eq("id", subtaskId).select().single()

      if (error) throw error

      return data
    } catch (error) {
      console.error("Error updating subtask:", error)
      throw error
    }
  },

  // Delete a subtask
  async deleteSubtask(subtaskId) {
    try {
      const { error } = await supabase.from("subtasks").delete().eq("id", subtaskId)

      if (error) throw error

      return true
    } catch (error) {
      console.error("Error deleting subtask:", error)
      throw error
    }
  },

  // Complete a subtask
  async completeSubtask(subtaskId, userId) {
    try {
      // Get subtask details
      const { data: subtask, error: subtaskError } = await supabase
        .from("subtasks")
        .select("*")
        .eq("id", subtaskId)
        .single()

      if (subtaskError) throw subtaskError

      // Update subtask status
      const { error: updateError } = await supabase
        .from("subtasks")
        .update({
          status: "completed",
          completed_at: new Date().toISOString(),
        })
        .eq("id", subtaskId)

      if (updateError) throw updateError

      // Update user stats with XP
      await this.updateUserStatsOnSubtaskCompletion(userId, subtask)

      return true
    } catch (error) {
      console.error("Error completing subtask:", error)
      throw error
    }
  },

  // Update subtask status only
  async updateSubtaskStatus(subtaskId, status) {
    try {
      const updateData = { status }
      if (status === "completed") {
        updateData.completed_at = new Date().toISOString()
      }

      const { data, error } = await supabase.from("subtasks").update(updateData).eq("id", subtaskId).select().single()

      if (error) throw error

      return data
    } catch (error) {
      console.error("Error updating subtask status:", error)
      throw error
    }
  },

  // Helper: Update user stats when subtask is completed
  async updateUserStatsOnSubtaskCompletion(userId, subtask) {
    try {
      // Get current user stats
      const { data: currentStats, error: statsError } = await supabase
        .from("user_stats")
        .select("*")
        .eq("user_id", userId)
        .single()

      if (statsError && statsError.code !== "PGRST116") throw statsError

      const xpGained = subtask.xp_reward || 5
      const newTotalXP = (currentStats?.total_xp_gained || 0) + xpGained
      const newCurrentXP = (currentStats?.current_xp || 0) + xpGained

      // Calculate new level
      const newLevel = Math.floor(newTotalXP / 100) + 1

      const statsUpdate = {
        current_xp: newCurrentXP,
        total_xp_gained: newTotalXP,
        level: newLevel,
        last_active_date: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      }

      if (currentStats) {
        // Update existing stats
        const { error: updateError } = await supabase.from("user_stats").update(statsUpdate).eq("user_id", userId)

        if (updateError) throw updateError
      } else {
        // Create new stats record
        const { error: insertError } = await supabase.from("user_stats").insert([
          {
            user_id: userId,
            ...statsUpdate,
          },
        ])

        if (insertError) throw insertError
      }
    } catch (error) {
      console.error("Error updating user stats on subtask completion:", error)
      throw error
    }
  },
}
