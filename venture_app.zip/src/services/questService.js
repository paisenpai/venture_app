import { supabase } from "../lib/supabase"

export const questService = {
  // Get all quests for a user
  async getUserQuests(userId) {
    try {
      const { data: quests, error } = await supabase
        .from("tasks")
        .select(`
          *,
          subtasks (*)
        `)
        .eq("user_id", userId)
        .order("created_at", { ascending: false })

      if (error) throw error

      return quests || []
    } catch (error) {
      console.error("Error fetching quests:", error)
      throw error
    }
  },

  // Create a new quest
  async createQuest(questData) {
    try {
      const { data, error } = await supabase.from("tasks").insert([questData]).select().single()

      if (error) throw error

      return data
    } catch (error) {
      console.error("Error creating quest:", error)
      throw error
    }
  },

  // Update a quest
  async updateQuest(questId, questData) {
    try {
      const { data, error } = await supabase.from("tasks").update(questData).eq("id", questId).select().single()

      if (error) throw error

      return data
    } catch (error) {
      console.error("Error updating quest:", error)
      throw error
    }
  },

  // Delete a quest
  async deleteQuest(questId) {
    try {
      const { error } = await supabase.from("tasks").delete().eq("id", questId)

      if (error) throw error

      return true
    } catch (error) {
      console.error("Error deleting quest:", error)
      throw error
    }
  },

  // Complete a quest (handles XP, achievements, etc.)
  async completeQuest(questId, userId) {
    try {
      // Get quest details
      const { data: quest, error: questError } = await supabase.from("tasks").select("*").eq("id", questId).single()

      if (questError) throw questError

      // Update quest status
      const { error: updateError } = await supabase
        .from("tasks")
        .update({
          status: "completed",
          completed_at: new Date().toISOString(),
        })
        .eq("id", questId)

      if (updateError) throw updateError

      // Update user stats
      await this.updateUserStatsOnCompletion(userId, quest)

      // Log daily activity
      await this.logDailyActivity(userId, quest.xp_reward || 10)

      // Check for achievements
      await this.checkAchievements(userId)

      return true
    } catch (error) {
      console.error("Error completing quest:", error)
      throw error
    }
  },

  // Update quest status only
  async updateQuestStatus(questId, status) {
    try {
      const updateData = { status }
      if (status === "completed") {
        updateData.completed_at = new Date().toISOString()
      }

      const { data, error } = await supabase.from("tasks").update(updateData).eq("id", questId).select().single()

      if (error) throw error

      return data
    } catch (error) {
      console.error("Error updating quest status:", error)
      throw error
    }
  },

  // Helper: Update user stats when quest is completed
  async updateUserStatsOnCompletion(userId, quest) {
    try {
      // Get current user stats
      const { data: currentStats, error: statsError } = await supabase
        .from("user_stats")
        .select("*")
        .eq("user_id", userId)
        .single()

      if (statsError && statsError.code !== "PGRST116") throw statsError

      const xpGained = quest.xp_reward || 10
      const newTotalXP = (currentStats?.total_xp_gained || 0) + xpGained
      const newCurrentXP = (currentStats?.current_xp || 0) + xpGained
      const newTasksCompleted = (currentStats?.tasks_completed || 0) + 1

      // Calculate new level (simple formula: level = floor(totalXP / 100) + 1)
      const newLevel = Math.floor(newTotalXP / 100) + 1

      const statsUpdate = {
        user_id: userId,
        current_xp: newCurrentXP,
        total_xp_gained: newTotalXP,
        level: newLevel,
        tasks_completed: newTasksCompleted,
        last_active_date: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      }

      if (currentStats) {
        // Update existing stats
        const { error: updateError } = await supabase.from("user_stats").update(statsUpdate).eq("user_id", userId)

        if (updateError) throw updateError
      } else {
        // Create new stats record
        const { error: insertError } = await supabase.from("user_stats").insert([statsUpdate])

        if (insertError) throw insertError
      }

      // Update character stats if quest has stat bonuses
      if (
        quest.strength_bonus ||
        quest.intelligence_bonus ||
        quest.wisdom_bonus ||
        quest.charisma_bonus ||
        quest.agility_bonus ||
        quest.endurance_bonus
      ) {
        await this.updateCharacterStats(userId, quest)
      }
    } catch (error) {
      console.error("Error updating user stats:", error)
      throw error
    }
  },

  // Helper: Update character stats
  async updateCharacterStats(userId, quest) {
    try {
      const { data: currentStats, error: statsError } = await supabase
        .from("character_stats")
        .select("*")
        .eq("user_id", userId)
        .single()

      if (statsError && statsError.code !== "PGRST116") throw statsError

      const statsUpdate = {
        user_id: userId,
        strength: (currentStats?.strength || 10) + (quest.strength_bonus || 0),
        intelligence: (currentStats?.intelligence || 10) + (quest.intelligence_bonus || 0),
        wisdom: (currentStats?.wisdom || 10) + (quest.wisdom_bonus || 0),
        charisma: (currentStats?.charisma || 10) + (quest.charisma_bonus || 0),
        agility: (currentStats?.agility || 10) + (quest.agility_bonus || 0),
        endurance: (currentStats?.endurance || 10) + (quest.endurance_bonus || 0),
        updated_at: new Date().toISOString(),
      }

      if (currentStats) {
        const { error: updateError } = await supabase.from("character_stats").update(statsUpdate).eq("user_id", userId)

        if (updateError) throw updateError
      } else {
        const { error: insertError } = await supabase.from("character_stats").insert([statsUpdate])

        if (insertError) throw insertError
      }
    } catch (error) {
      console.error("Error updating character stats:", error)
      throw error
    }
  },

  // Helper: Log daily activity
  async logDailyActivity(userId, xpGained) {
    try {
      const today = new Date().toISOString().split("T")[0]

      // Check if there's already an entry for today
      const { data: existingActivity, error: fetchError } = await supabase
        .from("daily_activity")
        .select("*")
        .eq("user_id", userId)
        .eq("activity_date", today)
        .single()

      if (fetchError && fetchError.code !== "PGRST116") throw fetchError

      if (existingActivity) {
        // Update existing entry
        const { error: updateError } = await supabase
          .from("daily_activity")
          .update({
            tasks_completed: existingActivity.tasks_completed + 1,
            xp_gained: existingActivity.xp_gained + xpGained,
          })
          .eq("id", existingActivity.id)

        if (updateError) throw updateError
      } else {
        // Create new entry
        const { error: insertError } = await supabase.from("daily_activity").insert([
          {
            user_id: userId,
            activity_date: today,
            tasks_completed: 1,
            xp_gained: xpGained,
          },
        ])

        if (insertError) throw insertError
      }

      // Update streak
      await this.updateStreak(userId)
    } catch (error) {
      console.error("Error logging daily activity:", error)
      throw error
    }
  },

  // Helper: Update user streak
  async updateStreak(userId) {
    try {
      // Get last 30 days of activity
      const thirtyDaysAgo = new Date()
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30)

      const { data: activities, error } = await supabase
        .from("daily_activity")
        .select("activity_date")
        .eq("user_id", userId)
        .gte("activity_date", thirtyDaysAgo.toISOString().split("T")[0])
        .order("activity_date", { ascending: false })

      if (error) throw error

      // Calculate current streak
      let currentStreak = 0
      let maxStreak = 0
      let tempStreak = 0

      const today = new Date().toISOString().split("T")[0]
      const activityDates = activities.map((a) => a.activity_date)

      // Check if user has activity today
      if (activityDates.includes(today)) {
        currentStreak = 1
        tempStreak = 1

        // Check consecutive days backwards
        for (let i = 1; i < 30; i++) {
          const checkDate = new Date()
          checkDate.setDate(checkDate.getDate() - i)
          const checkDateStr = checkDate.toISOString().split("T")[0]

          if (activityDates.includes(checkDateStr)) {
            currentStreak++
            tempStreak++
          } else {
            break
          }
        }
      }

      // Calculate max streak from all activities
      let consecutiveDays = 0
      for (let i = 0; i < activityDates.length; i++) {
        if (i === 0) {
          consecutiveDays = 1
        } else {
          const currentDate = new Date(activityDates[i])
          const previousDate = new Date(activityDates[i - 1])
          const dayDiff = (previousDate - currentDate) / (1000 * 60 * 60 * 24)

          if (dayDiff === 1) {
            consecutiveDays++
          } else {
            maxStreak = Math.max(maxStreak, consecutiveDays)
            consecutiveDays = 1
          }
        }
      }
      maxStreak = Math.max(maxStreak, consecutiveDays, currentStreak)

      // Update user stats with new streak
      const { error: updateError } = await supabase
        .from("user_stats")
        .update({
          current_streak: currentStreak,
          max_streak: maxStreak,
        })
        .eq("user_id", userId)

      if (updateError) throw updateError
    } catch (error) {
      console.error("Error updating streak:", error)
      throw error
    }
  },

  // Helper: Check for new achievements
  async checkAchievements(userId) {
    try {
      // This is a placeholder - you can implement achievement checking logic here
      // For now, we'll just log that we're checking achievements
      console.log("Checking achievements for user:", userId)
    } catch (error) {
      console.error("Error checking achievements:", error)
      throw error
    }
  },
}
