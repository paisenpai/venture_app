import { supabase } from "../lib/supabase"

export const userService = {
  // Get user profile
  async getUserProfile(userId) {
    try {
      const { data, error } = await supabase.from("profiles").select("*").eq("id", userId).single()

      if (error) throw error

      return data
    } catch (error) {
      console.error("Error fetching user profile:", error)
      throw error
    }
  },

  // Update user profile
  async updateUserProfile(userId, profileData) {
    try {
      const { data, error } = await supabase.from("profiles").update(profileData).eq("id", userId).select().single()

      if (error) throw error

      return data
    } catch (error) {
      console.error("Error updating user profile:", error)
      throw error
    }
  },

  // Get user stats
  async getUserStats(userId) {
    try {
      const { data, error } = await supabase.from("user_stats").select("*").eq("user_id", userId).single()

      if (error && error.code !== "PGRST116") throw error

      // Return default stats if no record exists
      if (!data) {
        return {
          user_id: userId,
          current_xp: 0,
          total_xp_gained: 0,
          level: 1,
          tasks_completed: 0,
          tasks_created: 0,
          current_streak: 0,
          max_streak: 0,
          last_active_date: new Date().toISOString(),
        }
      }

      return data
    } catch (error) {
      console.error("Error fetching user stats:", error)
      throw error
    }
  },

  // Update user stats
  async updateUserStats(userId, statsData) {
    try {
      const { data, error } = await supabase
        .from("user_stats")
        .upsert({
          user_id: userId,
          ...statsData,
          updated_at: new Date().toISOString(),
        })
        .select()
        .single()

      if (error) throw error

      return data
    } catch (error) {
      console.error("Error updating user stats:", error)
      throw error
    }
  },

  // Get character stats
  async getCharacterStats(userId) {
    try {
      const { data, error } = await supabase.from("character_stats").select("*").eq("user_id", userId).single()

      if (error && error.code !== "PGRST116") throw error

      // Return default stats if no record exists
      if (!data) {
        return {
          user_id: userId,
          strength: 10,
          intelligence: 10,
          wisdom: 10,
          charisma: 10,
          agility: 10,
          endurance: 10,
          total_stat_points: 60,
          available_stat_points: 0,
        }
      }

      return data
    } catch (error) {
      console.error("Error fetching character stats:", error)
      throw error
    }
  },

  // Update character stats
  async updateCharacterStats(userId, statsData) {
    try {
      const { data, error } = await supabase
        .from("character_stats")
        .upsert({
          user_id: userId,
          ...statsData,
          updated_at: new Date().toISOString(),
        })
        .select()
        .single()

      if (error) throw error

      return data
    } catch (error) {
      console.error("Error updating character stats:", error)
      throw error
    }
  },

  // Get user achievements
  async getUserAchievements(userId) {
    try {
      const { data, error } = await supabase
        .from("user_achievement_progress")
        .select(`
          *,
          achievement_definitions (*)
        `)
        .eq("user_id", userId)

      if (error) throw error

      return data || []
    } catch (error) {
      console.error("Error fetching user achievements:", error)
      throw error
    }
  },

  // Get daily activity
  async getDailyActivity(userId, days = 30) {
    try {
      const startDate = new Date()
      startDate.setDate(startDate.getDate() - days)

      const { data, error } = await supabase
        .from("daily_activity")
        .select("*")
        .eq("user_id", userId)
        .gte("activity_date", startDate.toISOString().split("T")[0])
        .order("activity_date", { ascending: true })

      if (error) throw error

      return data || []
    } catch (error) {
      console.error("Error fetching daily activity:", error)
      throw error
    }
  },

  // Initialize user data (called after registration)
  async initializeUser(userId, email, fullName) {
    try {
      // Create profile
      const { error: profileError } = await supabase.from("profiles").insert([
        {
          id: userId,
          email: email,
          full_name: fullName,
          username: fullName?.split(" ")[0] || "User",
          is_active: true,
          email_verified: false,
          created_at: new Date().toISOString(),
        },
      ])

      if (profileError) throw profileError

      // Create initial user stats
      const { error: statsError } = await supabase.from("user_stats").insert([
        {
          user_id: userId,
          current_xp: 0,
          total_xp_gained: 0,
          level: 1,
          tasks_completed: 0,
          tasks_created: 0,
          current_streak: 0,
          max_streak: 0,
          last_active_date: new Date().toISOString(),
        },
      ])

      if (statsError) throw statsError

      // Create initial character stats
      const { error: characterError } = await supabase.from("character_stats").insert([
        {
          user_id: userId,
          strength: 10,
          intelligence: 10,
          wisdom: 10,
          charisma: 10,
          agility: 10,
          endurance: 10,
          total_stat_points: 60,
          available_stat_points: 0,
        },
      ])

      if (characterError) throw characterError

      return true
    } catch (error) {
      console.error("Error initializing user:", error)
      throw error
    }
  },

  // Check for new achievements
  async checkAchievements(userId) {
    try {
      // Get user stats
      const userStats = await this.getUserStats(userId)
      const dailyActivity = await this.getDailyActivity(userId, 365)

      // Get all achievement definitions
      const { data: achievements, error } = await supabase
        .from("achievement_definitions")
        .select("*")
        .eq("is_active", true)

      if (error) throw error

      // Check each achievement
      for (const achievement of achievements) {
        const hasAchievement = await this.checkUserHasAchievement(userId, achievement.id)

        if (!hasAchievement && this.meetsAchievementRequirements(achievement, userStats, dailyActivity)) {
          await this.unlockAchievement(userId, achievement.id)
        }
      }
    } catch (error) {
      console.error("Error checking achievements:", error)
      throw error
    }
  },

  // Helper: Check if user has achievement
  async checkUserHasAchievement(userId, achievementId) {
    try {
      const { data, error } = await supabase
        .from("user_achievement_progress")
        .select("id")
        .eq("user_id", userId)
        .eq("achievement_id", achievementId)
        .eq("is_completed", true)
        .single()

      if (error && error.code !== "PGRST116") throw error

      return !!data
    } catch (error) {
      console.error("Error checking user achievement:", error)
      return false
    }
  },

  // Helper: Check if user meets achievement requirements
  meetsAchievementRequirements(achievement, userStats, dailyActivity) {
    switch (achievement.category) {
      case "level":
        return userStats.level >= achievement.required_count
      case "xp":
        return userStats.total_xp_gained >= achievement.required_count
      case "tasks":
        return userStats.tasks_completed >= achievement.required_count
      case "streak":
        return userStats.max_streak >= achievement.required_days
      case "daily_consistency":
        return userStats.current_streak >= achievement.required_days
      default:
        return false
    }
  },

  // Helper: Unlock achievement
  async unlockAchievement(userId, achievementId) {
    try {
      const { error } = await supabase.from("user_achievement_progress").insert([
        {
          user_id: userId,
          achievement_id: achievementId,
          is_completed: true,
          completed_at: new Date().toISOString(),
          current_progress: 100,
        },
      ])

      if (error) throw error

      console.log("Achievement unlocked:", achievementId)
    } catch (error) {
      console.error("Error unlocking achievement:", error)
      throw error
    }
  },
}
