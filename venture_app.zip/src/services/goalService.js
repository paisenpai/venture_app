import { supabase } from "../lib/supabase"

export const goalService = {
  // Get all goals for a user
  async getUserGoals(userId) {
    try {
      const { data, error } = await supabase
        .from("goals")
        .select("*")
        .eq("user_id", userId)
        .order("created_at", { ascending: false })

      if (error) throw error

      return data || []
    } catch (error) {
      console.error("Error fetching goals:", error)
      throw error
    }
  },

  // Create a new goal
  async createGoal(goalData) {
    try {
      const { data, error } = await supabase.from("goals").insert([goalData]).select().single()

      if (error) throw error

      return data
    } catch (error) {
      console.error("Error creating goal:", error)
      throw error
    }
  },

  // Update a goal
  async updateGoal(goalId, goalData) {
    try {
      const { data, error } = await supabase
        .from("goals")
        .update({
          ...goalData,
          updated_at: new Date().toISOString(),
        })
        .eq("id", goalId)
        .select()
        .single()

      if (error) throw error

      return data
    } catch (error) {
      console.error("Error updating goal:", error)
      throw error
    }
  },

  // Delete a goal
  async deleteGoal(goalId) {
    try {
      const { error } = await supabase.from("goals").delete().eq("id", goalId)

      if (error) throw error

      return true
    } catch (error) {
      console.error("Error deleting goal:", error)
      throw error
    }
  },

  // Update goal progress
  async updateGoalProgress(goalId, currentValue) {
    try {
      // Get goal details
      const { data: goal, error: goalError } = await supabase.from("goals").select("*").eq("id", goalId).single()

      if (goalError) throw goalError

      const isCompleted = currentValue >= goal.target_value
      const updateData = {
        current_value: currentValue,
        updated_at: new Date().toISOString(),
      }

      if (isCompleted && !goal.is_completed) {
        updateData.is_completed = true
        updateData.completed_at = new Date().toISOString()
      }

      const { data, error } = await supabase.from("goals").update(updateData).eq("id", goalId).select().single()

      if (error) throw error

      return data
    } catch (error) {
      console.error("Error updating goal progress:", error)
      throw error
    }
  },
}
