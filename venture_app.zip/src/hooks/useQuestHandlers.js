"use client"

import { useState, useEffect, useCallback } from "react"
import { useAuth } from "../contexts/AuthContext"
import { questService } from "../services/questService"
import { subtaskService } from "../services/subtaskService"
import { userService } from "../services/userService"

const useQuestHandlersDB = () => {
  const { user } = useAuth()
  const [quests, setQuests] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  // Load quests from database
  const loadQuests = useCallback(async () => {
    if (!user?.id) {
      setQuests([])
      setLoading(false)
      return
    }

    try {
      setLoading(true)
      setError(null)

      const questsData = await questService.getUserQuests(user.id)

      // Transform database data to match component expectations
      const transformedQuests = questsData.map((quest) => ({
        id: quest.id,
        name: quest.title,
        category: quest.category,
        goal: quest.description,
        dueDate: quest.due_date ? new Date(quest.due_date).toISOString().split("T")[0] : null,
        xp: quest.xp_reward || 10,
        priority: quest.priority === "low" ? 1 : quest.priority === "medium" ? 2 : quest.priority === "high" ? 3 : 4,
        status: quest.status,
        progress: quest.status === "completed" ? 100 : quest.status === "ongoing" ? 50 : 0,
        daysLeft: quest.due_date ? calculateDaysLeft(quest.due_date) : null,
        subtasks:
          quest.subtasks?.map((subtask) => ({
            id: subtask.id,
            name: subtask.title,
            category: "Subtask",
            goal: subtask.description,
            dueDate: subtask.due_date ? new Date(subtask.due_date).toISOString().split("T")[0] : null,
            xp: subtask.xp_reward || 5,
            priority:
              subtask.priority === "low" ? 1 : subtask.priority === "medium" ? 2 : subtask.priority === "high" ? 3 : 4,
            status: subtask.status,
            progress: subtask.status === "completed" ? 100 : subtask.status === "ongoing" ? 50 : 0,
            daysLeft: subtask.due_date ? calculateDaysLeft(subtask.due_date) : null,
          })) || [],
      }))

      setQuests(transformedQuests)
    } catch (err) {
      console.error("Error loading quests:", err)
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }, [user?.id])

  // Load quests when user changes
  useEffect(() => {
    loadQuests()
  }, [loadQuests])

  // Helper function to calculate days left
  const calculateDaysLeft = (dueDate) => {
    if (!dueDate) return null
    const today = new Date()
    today.setHours(0, 0, 0, 0)
    const due = new Date(dueDate)
    due.setHours(0, 0, 0, 0)
    const diffTime = due - today
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
    return diffDays
  }

  // Transform component data to database format
  const transformToDBFormat = (questData) => {
    return {
      title: questData.name,
      description: questData.goal,
      category: questData.category,
      due_date: questData.dueDate ? new Date(questData.dueDate).toISOString() : null,
      xp_reward: questData.xp || 10,
      priority:
        questData.priority === 1
          ? "low"
          : questData.priority === 2
            ? "medium"
            : questData.priority === 3
              ? "high"
              : "critical",
      status: questData.status || "available",
      user_id: user.id,
    }
  }

  // Transform subtask data to database format
  const transformSubtaskToDBFormat = (subtaskData, parentId) => {
    return {
      title: subtaskData.name,
      description: subtaskData.goal,
      parent_task_id: parentId,
      due_date: subtaskData.dueDate ? new Date(subtaskData.dueDate).toISOString() : null,
      xp_reward: subtaskData.xp || 5,
      priority:
        subtaskData.priority === 1
          ? "low"
          : subtaskData.priority === 2
            ? "medium"
            : subtaskData.priority === 3
              ? "high"
              : "critical",
      status: subtaskData.status || "available",
      user_id: user.id,
    }
  }

  // Add a new quest
  const handleAddQuest = useCallback(
    async (questData) => {
      if (!user?.id) {
        setError("User not authenticated")
        return
      }

      try {
        setError(null)
        const dbQuestData = transformToDBFormat(questData)
        await questService.createQuest(dbQuestData)

        // Update task creation count
        const userStats = await userService.getUserStats(user.id)
        await userService.updateUserStats(user.id, {
          tasks_created: userStats.tasks_created + 1,
        })

        // Reload quests to get the updated list
        await loadQuests()
      } catch (err) {
        console.error("Error adding quest:", err)
        setError(err.message)
        throw err
      }
    },
    [user?.id, loadQuests],
  )

  // Edit an existing quest
  const handleEditQuest = useCallback(
    async (questId, questData) => {
      if (!user?.id) {
        setError("User not authenticated")
        return
      }

      try {
        setError(null)
        const dbQuestData = transformToDBFormat(questData)
        await questService.updateQuest(questId, dbQuestData)
        await loadQuests()
      } catch (err) {
        console.error("Error editing quest:", err)
        setError(err.message)
        throw err
      }
    },
    [user?.id, loadQuests],
  )

  // Delete a quest
  const handleDeleteQuest = useCallback(
    async (questId) => {
      if (!user?.id) {
        setError("User not authenticated")
        return
      }

      try {
        setError(null)
        await questService.deleteQuest(questId)
        await loadQuests()
      } catch (err) {
        console.error("Error deleting quest:", err)
        setError(err.message)
        throw err
      }
    },
    [user?.id, loadQuests],
  )

  // Change quest status
  const handleChangeStatus = useCallback(
    async (questId, newStatus) => {
      if (!user?.id) {
        setError("User not authenticated")
        return
      }

      try {
        setError(null)

        if (newStatus === "completed") {
          // Use the complete quest method which handles XP and achievements
          await questService.completeQuest(questId, user.id)
        } else {
          // Just update the status
          await questService.updateQuest(questId, { status: newStatus })
        }

        await loadQuests()
      } catch (err) {
        console.error("Error changing quest status:", err)
        setError(err.message)
        throw err
      }
    },
    [user?.id, loadQuests],
  )

  // Add subtask to a quest
  const handleAddSubtask = useCallback(
    async (parentId, subtaskData) => {
      if (!user?.id) {
        setError("User not authenticated")
        return
      }

      try {
        setError(null)
        const dbSubtaskData = transformSubtaskToDBFormat(subtaskData, parentId)
        await subtaskService.createSubtask(dbSubtaskData)
        await loadQuests()
      } catch (err) {
        console.error("Error adding subtask:", err)
        setError(err.message)
        throw err
      }
    },
    [user?.id, loadQuests],
  )

  // Edit a subtask
  const handleEditSubtask = useCallback(
    async (parentId, subtaskId, subtaskData) => {
      if (!user?.id) {
        setError("User not authenticated")
        return
      }

      try {
        setError(null)
        const dbSubtaskData = transformSubtaskToDBFormat(subtaskData, parentId)
        await subtaskService.updateSubtask(subtaskId, dbSubtaskData)
        await loadQuests()
      } catch (err) {
        console.error("Error editing subtask:", err)
        setError(err.message)
        throw err
      }
    },
    [user?.id, loadQuests],
  )

  // Delete a subtask
  const handleDeleteSubtask = useCallback(
    async (parentId, subtaskId) => {
      if (!user?.id) {
        setError("User not authenticated")
        return
      }

      try {
        setError(null)
        await subtaskService.deleteSubtask(subtaskId)
        await loadQuests()
      } catch (err) {
        console.error("Error deleting subtask:", err)
        setError(err.message)
        throw err
      }
    },
    [user?.id, loadQuests],
  )

  // Change subtask status
  const handleChangeSubtaskStatus = useCallback(
    async (parentId, subtaskId, newStatus) => {
      if (!user?.id) {
        setError("User not authenticated")
        return
      }

      try {
        setError(null)

        if (newStatus === "completed") {
          // Use the complete subtask method which handles XP
          await subtaskService.completeSubtask(subtaskId, user.id)
        } else {
          // Just update the status
          await subtaskService.updateSubtask(subtaskId, { status: newStatus })
        }

        await loadQuests()
      } catch (err) {
        console.error("Error changing subtask status:", err)
        setError(err.message)
        throw err
      }
    },
    [user?.id, loadQuests],
  )

  // Update quest progress directly
  const updateQuestProgress = useCallback(
    async (questId, progress) => {
      if (!user?.id) {
        setError("User not authenticated")
        return
      }

      try {
        setError(null)
        await questService.updateQuest(questId, { progress })
        await loadQuests()
      } catch (err) {
        console.error("Error updating quest progress:", err)
        setError(err.message)
        throw err
      }
    },
    [user?.id, loadQuests],
  )

  // Refresh quests manually
  const refreshQuests = useCallback(async () => {
    await loadQuests()
  }, [loadQuests])

  return {
    quests,
    loading,
    error,
    handleAddQuest,
    handleEditQuest,
    handleDeleteQuest,
    handleChangeStatus,
    handleAddSubtask,
    handleEditSubtask,
    handleDeleteSubtask,
    handleChangeSubtaskStatus,
    updateQuestProgress,
    refreshQuests,
  }
}

export default useQuestHandlersDB
