# Contexts

This directory contains the implementation of global state management for the application using React Context. It provides shared state and functionality across different components of the app, enabling seamless data flow and reducing the need for prop drilling.